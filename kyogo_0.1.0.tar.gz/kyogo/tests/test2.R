library(kyogo)

hello()
